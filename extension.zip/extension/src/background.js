// Friday AI — Background Service Worker
// Routes messages between popup↔content↔Flask server

const SERVER = "http://localhost:7723";

// ── Context menu ──────────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ id:"friday-run",    title:"⚡ Friday: Run instruction on this page", contexts:["page","selection"] });
  chrome.contextMenus.create({ id:"friday-read",   title:"📖 Friday: Read this page",              contexts:["page"] });
  chrome.contextMenus.create({ id:"friday-fill",   title:"🤖 Friday: Auto-fill form",              contexts:["page"] });
  chrome.contextMenus.create({ id:"friday-record", title:"⏺ Friday: Start recording session",     contexts:["page"] });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "friday-read") {
    chrome.tabs.sendMessage(tab.id, {type:"EXECUTE", command:"read_page", args:{}});
  }
  if (info.menuItemId === "friday-fill") {
    chrome.action.openPopup();
  }
  if (info.menuItemId === "friday-record") {
    chrome.storage.local.set({recording: true, recordingTab: tab.id});
    chrome.tabs.sendMessage(tab.id, {type:"EXECUTE", command:"start_recording", args:{name:`session_${Date.now()}`}});
  }
});

// ── Message routing ───────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  // Popup: get active tab info
  if (msg.type === "GET_TAB_INFO") {
    chrome.tabs.query({active:true, currentWindow:true}, tabs => {
      sendResponse(tabs[0] ? {id:tabs[0].id, url:tabs[0].url, title:tabs[0].title, favIconUrl:tabs[0].favIconUrl} : {error:"No tab"});
    });
    return true;
  }

  // Popup: send command to content script of active tab
  if (msg.type === "EXEC_IN_TAB") {
    chrome.tabs.query({active:true, currentWindow:true}, tabs => {
      if (!tabs[0]) return sendResponse({ok:false, text:"No active tab"});
      chrome.tabs.sendMessage(tabs[0].id, {type:"EXECUTE", command:msg.command, args:msg.args||{}}, res => {
        sendResponse(res || {ok:false, text:chrome.runtime.lastError?.message || "No response"});
      });
    });
    return true;
  }

  // Popup: execute JS in tab
  if (msg.type === "EXEC_JS") {
    // MV3 REALITY: eval() and new Function() are both blocked — even in content scripts.
    // Solution: route to pre-defined DOM_OPS library in content.js via "dom_op" command.
    // The LLM sends op name + optional value instead of raw JS strings.
    chrome.tabs.query({active:true, currentWindow:true}, tabs => {
      if (!tabs[0]) return sendResponse({ok:false, text:"No active tab"});
      chrome.tabs.sendMessage(tabs[0].id,
        {type:"EXECUTE", command:"dom_op", args:{op: msg.op || "page_url", value: msg.value}},
        res => {
          if (chrome.runtime.lastError) {
            sendResponse({ok:false, text: chrome.runtime.lastError.message});
          } else {
            sendResponse(res || {ok:false, text:"Content script not responding"});
          }
        }
      );
    });
    return true;
  }

  // Popup: capture HTML
  if (msg.type === "CAPTURE_HTML") {
    chrome.tabs.query({active:true, currentWindow:true}, tabs => {
      if (!tabs[0]) return sendResponse({error:"No tab"});
      chrome.tabs.sendMessage(tabs[0].id, {type:"CAPTURE_HTML"}, res => {
        sendResponse(res || {error: chrome.runtime.lastError?.message});
      });
    });
    return true;
  }

  // Popup/content: call Flask server
  if (msg.type === "CALL_SERVER") {
    fetch(`${SERVER}${msg.path}`, {
      method: msg.method || "GET",
      headers: {"Content-Type":"application/json"},
      body: msg.body ? JSON.stringify(msg.body) : undefined,
    })
      .then(r => r.json())
      .then(data => sendResponse({ok:true, data}))
      .catch(err => sendResponse({ok:false, error:err.message}));
    return true;
  }

  // Health check
  if (msg.type === "HEALTH") {
    fetch(`${SERVER}/health`)
      .then(r => r.json())
      .then(d => sendResponse({ok:true, data:d}))
      .catch(() => sendResponse({ok:false}));
    return true;
  }

  // Get all tabs
  if (msg.type === "GET_ALL_TABS") {
    chrome.tabs.query({}, tabs => {
      sendResponse(tabs.map(t => ({id:t.id, url:t.url, title:t.title, active:t.active, index:t.index})));
    });
    return true;
  }

  // Focus/close tab by index
  if (msg.type === "FOCUS_TAB") {
    chrome.tabs.query({}, tabs => {
      const tab = tabs[msg.index];
      if (tab) chrome.tabs.update(tab.id, {active:true}, () => sendResponse({ok:true}));
      else sendResponse({ok:false, text:"Tab not found"});
    });
    return true;
  }

  if (msg.type === "CLOSE_TAB") {
    chrome.tabs.query({}, tabs => {
      const tab = msg.index != null ? tabs[msg.index] : null;
      if (msg.index == null) {
        chrome.tabs.query({active:true, currentWindow:true}, active => {
          if (active[0]) chrome.tabs.remove(active[0].id, () => sendResponse({ok:true}));
        });
      } else if (tab) {
        chrome.tabs.remove(tab.id, () => sendResponse({ok:true}));
      } else {
        sendResponse({ok:false, text:"Tab not found"});
      }
    });
    return true;
  }
});

// ── Badge: show server status ─────────────────────────────────────────────────
async function updateBadge() {
  try {
    const r = await fetch(`${SERVER}/health`, {signal: AbortSignal.timeout(2000)});
    if (r.ok) {
      chrome.action.setBadgeText({text: "ON"});
      chrome.action.setBadgeBackgroundColor({color: "#00ff9d"});
    } else throw new Error();
  } catch {
    chrome.action.setBadgeText({text: "OFF"});
    chrome.action.setBadgeBackgroundColor({color: "#ff4757"});
  }
}

// Check every 10 seconds
setInterval(updateBadge, 10000);
updateBadge();

// ── Extension Skills Loader ────────────────────────────────────────────────────
// Note: Skills in extension/skills/ folder need to be added to manifest.json
// under content_scripts.js array for static loading, OR injected dynamically here

// Inject custom skills into pages (for skills added after installation)
chrome.webNavigation.onCompleted.addListener(async (details) => {
  if (details.frameId !== 0) return; // Main frame only
  
  try {
    // Try to inject skills folder files
    // Note: In Manifest V3, we need to declare files in manifest.json
    // This is a placeholder for dynamic loading if skills are added later
    
    // For now, skills in extension/skills/ are loaded via manifest
    // Users should reload extension after adding new skills
  } catch (e) {
    console.log("Skill injection skipped:", e.message);
  }
});
