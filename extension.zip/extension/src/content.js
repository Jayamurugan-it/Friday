// Friday AI — Content Script
// Full DOM execution engine. Injected into every page.

const FRIDAY_SERVER = "http://localhost:7723";
let _recording = false;
let _recordingName = "";
let _recordedSteps = [];

// ── Extension Skills ───────────────────────────────────────────────────────────

window.FridaySkills = {
  _skills: {},
  
  register: function(skill) {
    if (!skill.name) {
      console.error("Friday: Skill must have a name");
      return false;
    }
    
    this._skills[skill.name] = skill;
    console.log(`✓ Friday skill loaded: ${skill.name} (${Object.keys(skill.commands || {}).length} commands)`);
    
    // Call onPageLoad if defined
    if (typeof skill.onPageLoad === 'function') {
      try {
        skill.onPageLoad();
      } catch (e) {
        console.error(`Friday: ${skill.name} onPageLoad error:`, e);
      }
    }
    
    return true;
  },
  
  list: function() {
    return Object.keys(this._skills);
  },
  
  get: function(name) {
    return this._skills[name];
  }
};

// Load all skills from extension/skills/ folder
// Skills will be injected by background.js when page loads

function executeExtensionSkill(skillName, commandName, args) {
  const skill = window.FridaySkills.get(skillName);
  
  if (!skill) {
    const available = window.FridaySkills.list();
    return {ok: false, text: `Skill '${skillName}' not found. Available: ${available.join(', ') || 'none'}`};
  }
  
  // Check if domain matches
  if (skill.domains && skill.domains.length > 0) {
    const currentDomain = window.location.hostname;
    const matches = skill.domains.some(d => 
      d === "*" || currentDomain.includes(d) || d.includes(currentDomain)
    );
    
    if (!matches) {
      return {ok: false, text: `Skill '${skillName}' only works on: ${skill.domains.join(', ')}`};
    }
  }
  
  // Execute command
  const command = skill.commands[commandName];
  if (!command) {
    return {ok: false, text: `Command '${commandName}' not found in ${skillName}. Available: ${Object.keys(skill.commands || {}).join(', ')}`};
  }
  
  try {
    // Call handler with args
    const result = command.handler ? command.handler(args) : command(args);
    
    // Handle promises
    if (result && typeof result.then === 'function') {
      return result.then(r => ({ok: r.ok !== false, text: r.text || r.message || JSON.stringify(r)}))
                   .catch(e => ({ok: false, text: `Skill error: ${e.message}`}));
    }
    
    return {ok: result.ok !== false, text: result.text || result.message || JSON.stringify(result)};
  } catch (e) {
    return {ok: false, text: `Skill error: ${e.message}`};
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

const sleep = ms => new Promise(r => setTimeout(r, ms));

function dispatchChange(el) {
  ["input","change","keyup","blur"].forEach(ev =>
    el.dispatchEvent(new Event(ev, {bubbles:true, cancelable:true}))
  );
}

function querySmart(selector, text, index=0) {
  if (selector) {
    try { const els = document.querySelectorAll(selector); return els[index] || null; }
    catch(e) { return null; }
  }
  if (text) {
    const all = [...document.querySelectorAll("a,button,input[type=submit],input[type=button],[role=button]")];
    const matches = all.filter(el => el.textContent.trim().toLowerCase().includes(text.toLowerCase())
                                   || el.value?.toLowerCase().includes(text.toLowerCase()));
    return matches[index] || null;
  }
  return null;
}

function findByDescription(desc) {
  desc = desc.toLowerCase();
  const all = document.querySelectorAll("input,button,a,select,textarea,[role=button],[role=link]");
  const scored = [...all].map(el => {
    const text = (el.textContent + el.placeholder + el.ariaLabel + el.title + el.name + el.id + el.className).toLowerCase();
    const score = text.split(" ").filter(w => desc.split(" ").includes(w)).length;
    return {el, score};
  }).filter(x => x.score > 0).sort((a,b) => b.score - a.score);
  return scored[0]?.el || null;
}

function extractPageText() {
  const clone = document.body.cloneNode(true);
  ["script","style","nav","footer","aside","noscript"].forEach(t => clone.querySelectorAll(t).forEach(e=>e.remove()));
  const text = clone.innerText || clone.textContent || "";
  return text.replace(/\s{3,}/g,"\n\n").trim().slice(0, 8000);
}

function tableToText(table) {
  const rows = [...table.querySelectorAll("tr")];
  return rows.map(r => [...r.querySelectorAll("th,td")].map(c=>c.textContent.trim()).join(" | ")).join("\n");
}

function record(type, data) {
  if (_recording) _recordedSteps.push({type, data, ts: Date.now()});
}

// ── Command executor ──────────────────────────────────────────────────────────

async function executeCommand(cmd, args) {
  // ── Extension Skills ──
  // Format: skill:[skillName]:[commandName]
  if (cmd.startsWith("skill:")) {
    const parts = cmd.split(":");
    const skillName = parts[1];
    const commandName = parts[2];
    return executeExtensionSkill(skillName, commandName, args);
  }
  
  switch(cmd) {

    // Navigation (handled by background for cross-tab, but some here)
    case "reload":   location.reload(); return {ok:true, text:"Reloaded"};

    // ── Pre-defined DOM operation library (CSP-safe, no eval/new Function) ──
    // MV3 blocks eval() and new Function() everywhere. All ops must be
    // pre-defined functions — no string evaluation ever.
    case "dom_op": {
      const op = args.op || "";
      const val = args.value;
      const DOM_OPS = {
        // Video controls — work on YouTube, Netflix, any <video> page
        video_play:    () => { const v = document.querySelector("video"); if(!v) return "No video"; v.play(); return "Playing"; },
        video_pause:   () => { const v = document.querySelector("video"); if(!v) return "No video"; v.pause(); return "Paused"; },
        video_toggle:  () => { const v = document.querySelector("video"); if(!v) return "No video"; v.paused ? v.play() : v.pause(); return v.paused ? "Paused" : "Playing"; },
        video_mute:    () => { const v = document.querySelector("video"); if(!v) return "No video"; v.muted = true;  return "Muted"; },
        video_unmute:  () => { const v = document.querySelector("video"); if(!v) return "No video"; v.muted = false; return "Unmuted"; },
        video_seek:    () => { const v = document.querySelector("video"); if(!v) return "No video"; v.currentTime += (parseFloat(val)||10); return `Seeked ${val}s`; },
        video_speed:   () => { const v = document.querySelector("video"); if(!v) return "No video"; v.playbackRate = parseFloat(val)||1; return `Speed ${val}x`; },
        video_volume:  () => { const v = document.querySelector("video"); if(!v) return "No video"; v.volume = Math.max(0, Math.min(1, parseInt(val,10)/100)); return `Volume ${val}%`; },
        video_info:    () => { const v = document.querySelector("video"); if(!v) return "No video"; return `duration=${Math.round(v.duration)}s pos=${Math.round(v.currentTime)}s speed=${v.playbackRate}x vol=${Math.round(v.volume*100)}% muted=${v.muted}`; },
        // Page scroll
        scroll_down:   () => { window.scrollBy(0,  parseInt(val,10)||500); return "Scrolled down"; },
        scroll_up:     () => { window.scrollBy(0, -(parseInt(val,10)||500)); return "Scrolled up"; },
        scroll_top:    () => { window.scrollTo(0, 0); return "Scrolled to top"; },
        scroll_bottom: () => { window.scrollTo(0, document.body.scrollHeight); return "Scrolled to bottom"; },
        // Page info
        page_title:    () => document.title,
        page_url:      () => location.href,
        page_text:     () => document.body && document.body.innerText.slice(0, 2000) || "",
        // Element interaction (CSS selector in val)
        click_el:      () => { const el = document.querySelector(val||"button"); if(!el) return "Not found: "+val; el.click(); return "Clicked: "+(el.textContent.slice(0,40)||val); },
        focus_el:      () => { const el = document.querySelector(val||"input"); if(!el) return "Not found: "+val; el.focus(); return "Focused"; },
        // Navigation
        open_url:      () => { window.open(val, "_blank"); return "Opened: "+val; },
        reload_page:   () => { location.reload(); return "Reloading"; },
      };
      const fn = DOM_OPS[op];
      if (!fn) return {ok: false, text: `Unknown dom_op: ${op}. Available: ${Object.keys(DOM_OPS).join(", ")}`};
      try {
        const result = fn();
        return {ok: true, text: String(result || "Done")};
      } catch(e) {
        return {ok: false, text: `dom_op ${op} error: ${e.message}`};
      }
    }
        case "get_url":  return {ok:true, text: location.href};
    case "get_title":return {ok:true, text: document.title};

    // Click
    case "click": {
      const el = querySmart(args.selector, args.text, args.index||0)
               || findByDescription(args.selector||args.text||"");
      if (!el) return {ok:false, text:`Element not found: ${args.selector||args.text}`};
      el.scrollIntoView({behavior:"smooth",block:"center"});
      await sleep(150);
      el.click();
      record("click", {selector: args.selector, text: args.text});
      return {ok:true, text:`Clicked: ${el.textContent?.trim()?.slice(0,40)||args.selector}`};
    }

    // Fill input
    case "fill_input": {
      const el = document.querySelector(args.selector);
      if (!el) return {ok:false, text:`Input not found: ${args.selector}`};
      if (args.clear_first !== false) { el.value = ""; dispatchChange(el); }
      el.focus();
      el.value = args.value;
      dispatchChange(el);
      // For React controlled inputs
      const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value')?.set
                                  || Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value')?.set;
      if (nativeInputValueSetter) { nativeInputValueSetter.call(el, args.value); dispatchChange(el); }
      record("fill_input", {selector:args.selector, value:args.value});
      return {ok:true, text:`Filled ${args.selector}: ${args.value?.slice(0,30)}`};
    }

    // Fill multiple fields
    case "fill_form": {
      const results = [];
      for (const [sel, val] of Object.entries(args.fields||{})) {
        // Try multiple selector strategies
        let el = null;
        const strategies = [sel,
          `input[name="${sel}"]`, `input[id="${sel}"]`, `input[placeholder*="${sel}"]`,
          `input[type="${sel}"]`, `[name="${sel}"]`, `#${sel}`, `[aria-label*="${sel}"]`
        ];
        for (const s of strategies) {
          try { el = document.querySelector(s); if (el) break; } catch(e){}
        }
        if (!el) { results.push(`✗ ${sel}`); continue; }
        el.focus(); el.value = val; dispatchChange(el);
        results.push(`✓ ${sel}`);
        await sleep(80);
      }
      record("fill_form", {fields:args.fields});
      return {ok:true, text:"Form filled:\n" + results.join("\n")};
    }

    // Auto-login (smart field detection)
    case "auto_login": {
      const {fields} = args; // {email,username,user → value}, {password,pass,pwd → value}
      let filled = [];
      for (const [keys, val] of Object.entries(fields)) {
        for (const key of keys.split(",")) {
          const sels = [`input[name*="${key}"]`,`input[id*="${key}"]`,`input[type="${key}"]`,`input[placeholder*="${key}"]`];
          for (const s of sels) {
            const el = document.querySelector(s);
            if (el) { el.focus(); el.value = val; dispatchChange(el); filled.push(key); await sleep(100); break; }
          }
        }
      }
      await sleep(300);
      // Click submit
      const submitEl = document.querySelector('button[type=submit],input[type=submit],[type=submit],button:last-of-type');
      if (submitEl) { submitEl.click(); filled.push("submit"); }
      return {ok:true, text:`Auto-login: filled ${filled.join(", ")}`};
    }

    // Select dropdown
    case "select_option": {
      const el = document.querySelector(args.selector);
      if (!el) return {ok:false, text:`Select not found: ${args.selector}`};
      if (args.value) el.value = args.value;
      else if (args.text) {
        [...el.options].forEach(o => { if(o.text.includes(args.text)) el.value = o.value; });
      }
      dispatchChange(el);
      return {ok:true, text:`Selected: ${el.value}`};
    }

    // Checkbox
    case "check_box": {
      const el = document.querySelector(args.selector);
      if (!el) return {ok:false, text:`Checkbox not found`};
      el.checked = args.checked !== false;
      dispatchChange(el);
      return {ok:true, text:`Checkbox ${el.checked?"checked":"unchecked"}`};
    }

    // Scroll
    case "scroll": {
      const el = args.selector ? document.querySelector(args.selector) : window;
      const amt = args.amount || 500;
      const dirs = {down:[0,amt], up:[0,-amt], left:[-amt,0], right:[amt,0]};
      const [x,y] = dirs[args.direction||"down"] || [0,amt];
      (el === window ? window : el).scrollBy({left:x, top:y, behavior:"smooth"});
      return {ok:true, text:`Scrolled ${args.direction||"down"} ${amt}px`};
    }

    // Hover
    case "hover": {
      const el = document.querySelector(args.selector);
      if (!el) return {ok:false, text:"Element not found"};
      el.dispatchEvent(new MouseEvent("mouseover",{bubbles:true}));
      el.dispatchEvent(new MouseEvent("mouseenter",{bubbles:true}));
      return {ok:true, text:`Hovered: ${args.selector}`};
    }

    // Key press
    case "press_key": {
      const target = args.selector ? document.querySelector(args.selector) : document.activeElement;
      const keyProps = {key:args.key, bubbles:true, cancelable:true};
      if (target) {
        ["keydown","keypress","keyup"].forEach(ev => target.dispatchEvent(new KeyboardEvent(ev,keyProps)));
      }
      return {ok:true, text:`Key pressed: ${args.key}`};
    }

    // Wait for element
    case "wait_for": {
      const timeout = args.timeout_ms || 5000;
      const start = Date.now();
      while (Date.now() - start < timeout) {
        if (document.querySelector(args.selector)) return {ok:true,text:`Found: ${args.selector}`};
        await sleep(200);
      }
      return {ok:false, text:`Timeout waiting for: ${args.selector}`};
    }

    // Get text
    case "get_text": {
      const el = args.selector ? document.querySelector(args.selector) : document.body;
      if (!el) return {ok:false, text:"Element not found"};
      return {ok:true, text: el.innerText?.slice(0,3000)||el.textContent?.slice(0,3000)};
    }

    // Get HTML
    case "get_html": {
      const el = args.selector ? document.querySelector(args.selector) : document.documentElement;
      if (!el) return {ok:false, text:"Element not found"};
      const html = args.outer ? el.outerHTML : el.innerHTML;
      return {ok:true, text: html.slice(0,5000)};
    }

    // Read entire page for Q&A
    case "read_page":
      return {ok:true, text: extractPageText()};

    // Extract table
    case "extract_table": {
      const tables = args.selector
        ? document.querySelectorAll(args.selector)
        : document.querySelectorAll("table");
      const table = tables[args.index||0];
      if (!table) return {ok:false, text:"No table found"};
      return {ok:true, text: tableToText(table)};
    }

    // Find element by description
    case "find_element": {
      const el = findByDescription(args.description);
      if (!el) return {ok:false, text:`No element matching "${args.description}"`};
      return {ok:true, text:`Found: ${el.tagName} "${el.textContent?.trim()?.slice(0,40)||el.name||el.id}"  selector: ${el.id?"#"+el.id:el.name?"[name="+el.name+"]":el.className?.split(" ")[0]||el.tagName.toLowerCase()}`};
    }

    // Get links
    case "get_links": {
      const container = args.selector ? document.querySelector(args.selector) : document;
      const links = [...(container||document).querySelectorAll("a[href]")].slice(0,40);
      return {ok:true, text: links.map(l=>`${l.textContent.trim().slice(0,40)} → ${l.href}`).join("\n")};
    }

    // Get form fields
    case "get_form_fields": {
      const fields = [...document.querySelectorAll("input,select,textarea")].slice(0,30);
      return {ok:true, text: fields.map(f=>`${f.tagName.toLowerCase()}[${f.type||""}] name="${f.name}" id="${f.id}" placeholder="${f.placeholder||""}"`).join("\n")};
    }

    // Get form values (for save_form)
    case "get_form_values": {
      const fields = {};
      document.querySelectorAll("input,select,textarea").forEach(f => {
        const key = f.name||f.id||f.placeholder;
        if (key && f.value) fields[key] = f.value;
      });
      return {ok:true, text: JSON.stringify(fields)};
    }

    // Fill form values (for fill_saved_form)
    case "fill_form_values": {
      const data = typeof args.fields === "string" ? JSON.parse(args.fields) : args.fields;
      let count = 0;
      for (const [key, val] of Object.entries(data)) {
        const el = document.querySelector(`[name="${key}"],[id="${key}"]`);
        if (el) { el.value = val; dispatchChange(el); count++; }
      }
      return {ok:true, text:`Filled ${count} fields`};
    }

    // Run arbitrary JS — BLOCKED by MV3 Content Security Policy (no eval/new Function)
    case "run_js": {
      return {ok:false, text:"run_js is not supported: Chrome MV3 extensions block eval() and new Function() via CSP. Use pre-defined dom_op commands instead."};
    }

    // Get storage
    case "get_storage": {
      const store = args.type === "session" ? sessionStorage : localStorage;
      const data = {};
      for (let i=0; i<store.length; i++) {
        const k = store.key(i);
        data[k] = store.getItem(k)?.slice(0,100);
      }
      return {ok:true, text: JSON.stringify(data, null, 2).slice(0,3000)};
    }

    // Recording
    case "start_recording":
      _recording = true; _recordingName = args.name; _recordedSteps = [];
      return {ok:true, text:`Recording started: ${args.name}. Interact with the page...`};

    case "stop_recording":
      _recording = false;
      // Send steps back to server
      fetch(`${FRIDAY_SERVER}/friday/browser/recording_done`, {
        method:"POST", headers:{"Content-Type":"application/json"},
        body:JSON.stringify({name:_recordingName, steps:_recordedSteps})
      });
      return {ok:true, text:`Recorded ${_recordedSteps.length} steps as "${_recordingName}"`};

    // Replay session
    case "replay_session": {
      const steps = args.steps || [];
      for (const step of steps) {
        await executeCommand(step.type, step.data || step);
        await sleep(300);
      }
      return {ok:true, text:`Replayed ${steps.length} steps`};
    }

    // Trigger download
    case "trigger_download": {
      const a = document.createElement("a");
      a.href = args.url; a.download = args.url.split("/").pop()||"download";
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      return {ok:true, text:`Download triggered: ${args.url}`};
    }

    default:
      return {ok:false, text:`Unknown command: ${cmd}`};
  }
}

// ── Poll server for commands ───────────────────────────────────────────────────

async function pollServer() {
  try {
    const resp = await fetch(`${FRIDAY_SERVER}/friday/browser/pending`);
    if (!resp.ok) return;
    const cmds = await resp.json();
    for (const c of cmds) {
      let result;
      try {
        result = await executeCommand(c.command, JSON.parse(c.args||"{}"));
      } catch(e) {
        result = {ok:false, text:`Exception: ${e.message}`};
      }
      // Post result back
      fetch(`${FRIDAY_SERVER}/friday/browser/result`, {
        method:"POST", headers:{"Content-Type":"application/json"},
        body:JSON.stringify({id:c.id, status:result.ok?"done":"error", result:result.text})
      }).catch(()=>{});
    }
  } catch(e) {
    // Server offline or not yet started
  }
}

// Poll every 500ms
setInterval(pollServer, 500);

// ── Message listener (from background/popup) ──────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "EXECUTE") {
    executeCommand(msg.command, msg.args || {})
      .then(result => sendResponse(result))
      .catch(e => sendResponse({ok:false, text:e.message}));
    return true;
  }
  if (msg.type === "PING") { sendResponse({alive:true, url:location.href, title:document.title}); return true; }
  if (msg.type === "CAPTURE_HTML") {
    const clone = document.documentElement.cloneNode(true);
    ["script","style","svg","canvas","noscript"].forEach(t => clone.querySelectorAll(t).forEach(e=>e.remove()));
    let html = clone.outerHTML.slice(0, 35000);
    sendResponse({html, url:location.href, title:document.title, chars:html.length});
    return true;
  }
});
