// Friday AI — Popup JS
// Handles browser tab, system tab, memory tab, settings tab

const SERVER = () => document.getElementById("set-server")?.value || "http://localhost:7723";

// ── State ─────────────────────────────────────────────────────────────────────
let currentCode  = "";
let history      = [];
let serverOnline = false;

// ── Init ──────────────────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", async () => {
  await loadSettings();
  checkServer();
  setInterval(checkServer, 8000);
  loadTabInfo();
  loadHistory();
  setupTabs();
  setupBrowserPanel();
  setupSystemPanel();
  setupMemoryPanel();
  setupSettings();
});

// ── Server health ─────────────────────────────────────────────────────────────
async function checkServer() {
  const dot = document.getElementById("statusDot");
  dot.className = "status-dot checking";
  try {
    const r = await fetch(`${SERVER()}/health`, { signal: AbortSignal.timeout(2500) });
    serverOnline = r.ok;
    dot.className = "status-dot" + (r.ok ? "" : " offline");
    document.getElementById("serverStatus").textContent = r.ok ? "server online" : "server offline";
  } catch {
    serverOnline = false;
    dot.className = "status-dot offline";
    document.getElementById("serverStatus").textContent = "server offline";
  }
}

// ── Tab info ──────────────────────────────────────────────────────────────────
function loadTabInfo() {
  chrome.runtime.sendMessage({ type: "GET_TAB_INFO" }, tab => {
    if (!tab || tab.error) return;
    document.getElementById("pageTitle").textContent = tab.title || "Untitled";
    const fav = document.getElementById("pageFavicon");
    if (tab.favIconUrl) { fav.src = tab.favIconUrl; fav.style.display = ""; }
    else fav.style.display = "none";
  });
}

// ── Tabs ──────────────────────────────────────────────────────────────────────
function setupTabs() {
  document.querySelectorAll(".tab").forEach(tab => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
      document.querySelectorAll(".panel").forEach(p => p.classList.remove("active"));
      tab.classList.add("active");
      document.getElementById(`panel-${tab.dataset.tab}`).classList.add("active");
      if (tab.dataset.tab === "memory") loadMemoryPanel();
    });
  });
  document.getElementById("settingsTabBtn").addEventListener("click", () => {
    document.querySelector("[data-tab='settings']").click();
  });
  document.getElementById("dashboardBtn").addEventListener("click", () => {
    chrome.tabs.create({ url: `${SERVER()}/dashboard` });
  });
}

// ═══════════════════════════════════════════════════════════
// BROWSER PANEL
// ═══════════════════════════════════════════════════════════

function setupBrowserPanel() {
  // Presets
  document.querySelectorAll(".preset").forEach(btn => {
    btn.addEventListener("click", () => {
      document.getElementById("instruction").value = btn.dataset.preset;
      document.getElementById("instruction").focus();
    });
  });

  // Clear
  document.getElementById("clearBtn").addEventListener("click", () => {
    document.getElementById("instruction").value = "";
    document.getElementById("instruction").focus();
  });

  // Run
  document.getElementById("runBtn").addEventListener("click", runBrowserAutomation);
  document.getElementById("instruction").addEventListener("keydown", e => {
    if (e.ctrlKey && e.key === "Enter") runBrowserAutomation();
  });

  // Copy
  document.getElementById("copyBtn").addEventListener("click", () => {
    navigator.clipboard.writeText(currentCode);
    document.getElementById("copyBtn").textContent = "Copied!";
    setTimeout(() => document.getElementById("copyBtn").textContent = "Copy", 1500);
  });

  // Re-run
  document.getElementById("rerunBtn").addEventListener("click", () => {
    if (currentCode) executeInTab(currentCode);
  });
}

function setPipelineStep(step, state) {
  // state: '' | 'active' | 'done' | 'error'
  document.getElementById(`step-${step}`).className = `pipe-step ${state}`;
}
function resetPipeline() {
  ["capture","send","ai","exec"].forEach(s => setPipelineStep(s, ""));
}

async function runBrowserAutomation() {
  const instruction = document.getElementById("instruction").value.trim();
  if (!instruction) return;

  const btn = document.getElementById("runBtn");
  btn.classList.add("loading");
  btn.disabled = true;
  resetPipeline();
  showResult("", "");
  document.getElementById("codeBox").style.display = "none";

  try {
    // Step 1: Capture HTML
    setPipelineStep("capture", "active");
    const htmlData = await new Promise(res =>
      chrome.runtime.sendMessage({ type: "CAPTURE_HTML" }, res)
    );
    if (!htmlData || htmlData.error) throw new Error("Could not capture page HTML");
    setPipelineStep("capture", "done");

    // Step 2: Send to server
    setPipelineStep("send", "active");
    if (!serverOnline) throw new Error("Friday server offline. Start server first.");

    const tabInfo = await new Promise(res =>
      chrome.runtime.sendMessage({ type: "GET_TAB_INFO" }, res)
    );

    setPipelineStep("send", "done");

    // Step 3: AI generates code
    setPipelineStep("ai", "active");
    const response = await fetch(`${SERVER()}/automate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        html: htmlData.html?.slice(0, 30000) || "",
        instruction,
        url:   tabInfo?.url   || "",
        title: tabInfo?.title || "",
      })
    });
    if (!response.ok) throw new Error(`Server error: ${response.status}`);
    const data = await response.json();
    const jsCode = data.js_code || data.code || "";
    if (!jsCode) throw new Error("AI returned no code");
    setPipelineStep("ai", "done");

    // Step 4: Execute
    setPipelineStep("exec", "active");
    const execResult = await executeInTab(jsCode);
    setPipelineStep("exec", execResult.ok ? "done" : "error");

    // Show result
    currentCode = jsCode;
    document.getElementById("codePre").textContent = jsCode;
    document.getElementById("codeBox").style.display = "block";

    if (execResult.ok) {
      showResult(`✓ ${data.explanation || "Done"}${execResult.text ? "\n" + execResult.text : ""}`, "success");
    } else {
      showResult(`⚠ Executed but got: ${execResult.text || "unknown error"}`, "info");
    }

    // Save to history
    saveToHistory(instruction, jsCode);

  } catch (err) {
    ["capture","send","ai","exec"].forEach(s => {
      const el = document.getElementById(`step-${s}`);
      if (el.classList.contains("active")) el.className = "pipe-step error";
    });
    showResult(`✗ ${err.message}`, "error");
  }

  btn.classList.remove("loading");
  btn.disabled = false;
}

async function executeInTab(code) {
  return new Promise(res => {
    chrome.runtime.sendMessage({ type: "EXEC_IN_TAB", command: "run_js", args: { code } }, result => {
      res(result || { ok: false, text: chrome.runtime.lastError?.message || "No response" });
    });
  });
}

function showResult(msg, type) {
  const el = document.getElementById("resultBanner");
  el.textContent = msg;
  el.className = `result-banner ${type}`;
  el.style.display = msg ? "block" : "none";
}

// ── History ───────────────────────────────────────────────────────────────────
function saveToHistory(instruction, code) {
  history.unshift({ instruction, code, ts: new Date().toLocaleTimeString() });
  if (history.length > 10) history.pop();
  chrome.storage.local.set({ friday_history: history });
  renderHistory();
}

function loadHistory() {
  chrome.storage.local.get(["friday_history"], data => {
    history = data.friday_history || [];
    renderHistory();
  });
}

function renderHistory() {
  const list = document.getElementById("historyList");
  list.innerHTML = "";
  if (!history.length) {
    document.getElementById("historyWrap").style.display = "none";
    return;
  }
  document.getElementById("historyWrap").style.display = "block";
  history.slice(0, 5).forEach(h => {
    const el = document.createElement("div");
    el.className = "history-item";
    el.innerHTML = `<span class="h-icon">⚡</span><span class="h-text">${h.instruction}</span><span class="h-time">${h.ts}</span>`;
    el.addEventListener("click", () => {
      document.getElementById("instruction").value = h.instruction;
      if (h.code) {
        currentCode = h.code;
        document.getElementById("codePre").textContent = h.code;
        document.getElementById("codeBox").style.display = "block";
      }
    });
    list.appendChild(el);
  });
}

// ═══════════════════════════════════════════════════════════
// SYSTEM PANEL
// ═══════════════════════════════════════════════════════════

function setupSystemPanel() {
  const input  = document.getElementById("cmd-input");
  const runBtn = document.getElementById("cmdRunBtn");
  const output = document.getElementById("cmdOutput");

  document.querySelectorAll(".sys-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      input.value = btn.dataset.cmd;
      sendCmdToFriday(btn.dataset.cmd);
    });
  });

  runBtn.addEventListener("click", () => sendCmdToFriday(input.value.trim()));
  input.addEventListener("keydown", e => {
    if (e.key === "Enter") sendCmdToFriday(input.value.trim());
  });

  function sendCmdToFriday(cmd) {
    if (!cmd) return;
    if (!serverOnline) {
      appendOutput("⚠ Server offline. Start Friday server first.", "line-err");
      return;
    }
    appendOutput(`❯ ${cmd}`, "line-tool");
    fetch(`${SERVER()}/friday/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: cmd })
    })
      .then(r => r.json())
      .then(d => appendOutput(d.reply || d.result || JSON.stringify(d), "line-ok"))
      .catch(e => appendOutput(`✗ ${e.message}`, "line-err"));
    input.value = "";
  }

  function appendOutput(text, cls = "") {
    const span = document.createElement("span");
    span.className = cls;
    span.textContent = "\n" + text;
    output.innerHTML === '<span style="color:var(--muted)">⚡ Friday CMD Arm — type a command or click a shortcut above</span>'
      ? (output.innerHTML = "", output.appendChild(span))
      : output.appendChild(span);
    output.scrollTop = output.scrollHeight;
  }
}

// ═══════════════════════════════════════════════════════════
// MEMORY PANEL
// ═══════════════════════════════════════════════════════════

async function loadMemoryPanel() {
  if (!serverOnline) return;
  try {
    // Reminders
    const rr = await fetch(`${SERVER()}/friday/data/reminders`).then(r=>r.json());
    renderReminders(rr.data || []);
    // Goals
    const gr = await fetch(`${SERVER()}/friday/data/goals`).then(r=>r.json());
    renderGoals(gr.data || []);
    // Habits
    const hr = await fetch(`${SERVER()}/friday/data/habits`).then(r=>r.json());
    renderHabits(hr.data || []);
  } catch {}
}

function setupMemoryPanel() {
  document.getElementById("addReminderBtn").addEventListener("click", async () => {
    const text = document.getElementById("reminderText").value.trim();
    if (!text) return;
    const when = prompt("When? (e.g. in 2 hours, tomorrow 9am)") || "in 1 hour";
    await fetch(`${SERVER()}/friday/chat`, {
      method:"POST", headers:{"Content-Type":"application/json"},
      body: JSON.stringify({ message: `remind me ${text} ${when}` })
    }).catch(()=>{});
    document.getElementById("reminderText").value = "";
    setTimeout(loadMemoryPanel, 500);
  });

  document.getElementById("addGoalBtn").addEventListener("click", async () => {
    const text = document.getElementById("goalText").value.trim();
    if (!text) return;
    await fetch(`${SERVER()}/friday/chat`, {
      method:"POST", headers:{"Content-Type":"application/json"},
      body: JSON.stringify({ message: `create goal: ${text}` })
    }).catch(()=>{});
    document.getElementById("goalText").value = "";
    setTimeout(loadMemoryPanel, 500);
  });

  document.getElementById("saveNoteBtn").addEventListener("click", async () => {
    const text = document.getElementById("noteText").value.trim();
    if (!text) return;
    await fetch(`${SERVER()}/friday/chat`, {
      method:"POST", headers:{"Content-Type":"application/json"},
      body: JSON.stringify({ message: `remember: ${text}` })
    }).catch(()=>{});
    document.getElementById("noteText").value = "";
    alert("Note saved!");
  });
}

function renderReminders(items) {
  const el = document.getElementById("reminderList");
  el.innerHTML = items.length ? "" : '<div class="mem-item"><span style="color:var(--muted)">No reminders</span></div>';
  items.slice(0,4).forEach(r => {
    const d = document.createElement("div");
    d.className = "mem-item";
    d.innerHTML = `<span>${r.text}</span><span class="mem-tag">${(r.due_time||"").slice(11,16)}</span>`;
    el.appendChild(d);
  });
}

function renderGoals(items) {
  const el = document.getElementById("goalList");
  el.innerHTML = items.length ? "" : '<div class="mem-item"><span style="color:var(--muted)">No goals</span></div>';
  items.slice(0,3).forEach(g => {
    const d = document.createElement("div");
    d.className = "mem-item";
    d.innerHTML = `<span>${g.title}</span><span class="mem-tag">${g.progress}%</span>`;
    el.appendChild(d);
  });
}

function renderHabits(items) {
  const el = document.getElementById("habitList");
  el.innerHTML = items.length ? "" : '<div class="mem-item"><span style="color:var(--muted)">No habits learned yet</span></div>';
  items.slice(0,6).forEach(h => {
    const d = document.createElement("div");
    d.className = "mem-item";
    d.innerHTML = `<span>${h.action}</span><span class="mem-tag">${h.preference}</span>`;
    el.appendChild(d);
  });
}

// ═══════════════════════════════════════════════════════════
// SETTINGS
// ═══════════════════════════════════════════════════════════

function setupSettings() {
  document.getElementById("saveSettingsBtn").addEventListener("click", saveSettings);
}

async function loadSettings() {
  return new Promise(res => {
    chrome.storage.sync.get(["friday_server","friday_timeout","friday_maxhtml","friday_poll"], d => {
      document.getElementById("set-server").value  = d.friday_server  || "http://localhost:7723";
      document.getElementById("set-timeout").value = d.friday_timeout || 30;
      document.getElementById("set-maxhtml").value = d.friday_maxhtml || 30000;
      document.getElementById("set-poll").value    = d.friday_poll    || 500;
      res();
    });
  });
}

function saveSettings() {
  chrome.storage.sync.set({
    friday_server:  document.getElementById("set-server").value,
    friday_timeout: parseInt(document.getElementById("set-timeout").value) || 30,
    friday_maxhtml: parseInt(document.getElementById("set-maxhtml").value) || 30000,
    friday_poll:    parseInt(document.getElementById("set-poll").value)    || 500,
  }, () => {
    const btn = document.getElementById("saveSettingsBtn");
    btn.textContent = "✓ Saved!";
    setTimeout(() => btn.textContent = "💾 Save Settings", 1500);
    checkServer();
  });
}
