# Friday Extension Skills

Drop `.js` skill files here to add custom browser automation!

---

## Quick Start

1. **Get template**: Say "Friday, extension skill template"
2. **Upload to Claude**: Ask Claude to generate skill
3. **Paste here**: Drop generated `.js` file in this folder
4. **Reload extension**: `chrome://extensions` → Reload Friday
5. **Use it**: Skills load automatically!

---

## Example Skills

Check `EXTENSION_SKILL_TEMPLATE.md` in the root folder for:
- YouTube controller (play/pause/volume/skip)
- Netflix controller (skip intro, next episode)
- Gmail shortcuts (compose, search, archive)
- Twitter actions (post, like, scroll)
- Universal reader (works on any site)

---

## File Format

```javascript
// my_skill.js

const MySkill = {
  name: "My Skill",
  version: "1.0",
  description: "Does something cool",
  domains: ["youtube.com"],  // optional
  
  commands: {
    my_command: {
      description: "Command description",
      handler: async (args) => {
        // Your code
        return { ok: true, text: "Done!" };
      }
    }
  },
  
  onPageLoad: () => {
    console.log("Skill loaded!");
  }
};

if (typeof window.FridaySkills !== 'undefined') {
  window.FridaySkills.register(MySkill);
}
```

---

## Usage

Once installed, use skills with Friday:

```
Friday, play youtube
Friday, pause youtube
Friday, youtube volume 80
Friday, netflix skip intro
Friday, gmail compose
```

---

## Tips

- Skills run in **content script context** (access to DOM)
- Can manipulate any webpage
- Use `console.log()` to debug
- Check DevTools console for errors
- Reload extension after adding skills

---

**Need help?** Check `EXTENSION_SKILL_TEMPLATE.md` for complete examples!
