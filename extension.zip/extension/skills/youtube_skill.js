// Friday Extension Skill: YouTube Controller
// Controls YouTube video playback with natural language commands

window.FridaySkills = window.FridaySkills || {};

window.FridaySkills.youtube = {
  name: "YouTube Controller",
  description: "Control YouTube videos - play, pause, skip, volume, speed",
  domains: ["youtube.com", "music.youtube.com"],
  
  commands: {
    
    play: function() {
      const video = document.querySelector('video');
      if (video) {
        video.play();
        return { ok: true, message: "▶ Playing" };
      }
      return { ok: false, message: "No video found" };
    },
    
    pause: function() {
      const video = document.querySelector('video');
      if (video) {
        video.pause();
        return { ok: true, message: "⏸ Paused" };
      }
      return { ok: false, message: "No video found" };
    },
    
    resume: function() {
      return this.play();
    },
    
    stop: function() {
      return this.pause();
    },
    
    mute: function() {
      const video = document.querySelector('video');
      if (video) {
        video.muted = true;
        return { ok: true, message: "🔇 Muted" };
      }
      return { ok: false, message: "No video found" };
    },
    
    unmute: function() {
      const video = document.querySelector('video');
      if (video) {
        video.muted = false;
        return { ok: true, message: "🔊 Unmuted" };
      }
      return { ok: false, message: "No video found" };
    },
    
    volume: function(level) {
      const video = document.querySelector('video');
      if (!video) {
        return { ok: false, message: "No video found" };
      }
      
      // Convert level (0-100) to 0-1 range
      const vol = Math.max(0, Math.min(100, parseInt(level))) / 100;
      video.volume = vol;
      return { ok: true, message: `🔊 Volume: ${Math.round(vol * 100)}%` };
    },
    
    speed: function(rate) {
      const video = document.querySelector('video');
      if (!video) {
        return { ok: false, message: "No video found" };
      }
      
      const speed = parseFloat(rate);
      if (speed < 0.25 || speed > 2.0) {
        return { ok: false, message: "Speed must be between 0.25 and 2.0" };
      }
      
      video.playbackRate = speed;
      return { ok: true, message: `⚡ Speed: ${speed}x` };
    },
    
    skip: function(seconds) {
      const video = document.querySelector('video');
      if (!video) {
        return { ok: false, message: "No video found" };
      }
      
      const secs = parseInt(seconds) || 10;
      video.currentTime += secs;
      return { ok: true, message: `⏩ Skipped ${secs}s` };
    },
    
    back: function(seconds) {
      const video = document.querySelector('video');
      if (!video) {
        return { ok: false, message: "No video found" };
      }
      
      const secs = parseInt(seconds) || 10;
      video.currentTime -= secs;
      return { ok: true, message: `⏪ Back ${secs}s` };
    },
    
    restart: function() {
      const video = document.querySelector('video');
      if (video) {
        video.currentTime = 0;
        return { ok: true, message: "⏮ Restarted" };
      }
      return { ok: false, message: "No video found" };
    },
    
    fullscreen: function() {
      const video = document.querySelector('video');
      if (!video) {
        return { ok: false, message: "No video found" };
      }
      
      if (video.requestFullscreen) {
        video.requestFullscreen();
      } else if (video.webkitRequestFullscreen) {
        video.webkitRequestFullscreen();
      } else if (video.mozRequestFullScreen) {
        video.mozRequestFullScreen();
      } else if (video.msRequestFullscreen) {
        video.msRequestFullscreen();
      }
      
      return { ok: true, message: "⛶ Fullscreen" };
    },
    
    info: function() {
      const video = document.querySelector('video');
      if (!video) {
        return { ok: false, message: "No video found" };
      }
      
      const current = Math.floor(video.currentTime);
      const duration = Math.floor(video.duration);
      const mins = Math.floor(current / 60);
      const secs = current % 60;
      const totalMins = Math.floor(duration / 60);
      const totalSecs = duration % 60;
      
      const status = video.paused ? '⏸ Paused' : '▶ Playing';
      const time = `${mins}:${secs.toString().padStart(2,'0')} / ${totalMins}:${totalSecs.toString().padStart(2,'0')}`;
      const vol = `Vol: ${Math.round(video.volume * 100)}%`;
      const speed = `Speed: ${video.playbackRate}x`;
      
      return {
        ok: true,
        message: `${status} | ${time} | ${vol} | ${speed}`,
        data: {
          playing: !video.paused,
          currentTime: video.currentTime,
          duration: video.duration,
          volume: video.volume,
          speed: video.playbackRate
        }
      };
    },
    
    next: function() {
      // Click next button
      const nextBtn = document.querySelector('.ytp-next-button');
      if (nextBtn) {
        nextBtn.click();
        return { ok: true, message: "⏭ Next video" };
      }
      return { ok: false, message: "Next button not found" };
    },
    
    previous: function() {
      // Restart current video (YouTube doesn't have previous)
      return this.restart();
    },
    
    like: function() {
      const likeBtn = document.querySelector('button[aria-label^="like this video"]');
      if (likeBtn) {
        likeBtn.click();
        return { ok: true, message: "👍 Liked" };
      }
      return { ok: false, message: "Like button not found" };
    },
    
    dislike: function() {
      const dislikeBtn = document.querySelector('button[aria-label^="Dislike"]');
      if (dislikeBtn) {
        dislikeBtn.click();
        return { ok: true, message: "👎 Disliked" };
      }
      return { ok: false, message: "Dislike button not found" };
    },
    
    subscribe: function() {
      const subBtn = document.querySelector('#subscribe-button button');
      if (subBtn) {
        subBtn.click();
        return { ok: true, message: "🔔 Subscribed" };
      }
      return { ok: false, message: "Subscribe button not found" };
    }
  }
};

console.log('✅ Friday YouTube Controller loaded');
